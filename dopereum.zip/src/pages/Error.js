import React from 'react'

export default function Error() {
  return (
    <div className="text-3xl font-bold dark:text-light-text">
      404 Not Found
    </div>
  )
}
